import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
const gold = '#D6B56D';
export default function TabLayout() {
  return <Tabs screenOptions={{headerShown:false, tabBarActiveTintColor:gold, tabBarInactiveTintColor:'#7D8798', tabBarStyle:{backgroundColor:'#0D1422',borderTopColor:'#202A3A',height:66,paddingTop:8,paddingBottom:8},tabBarLabelStyle:{fontSize:10,fontWeight:'600'}}}>
    <Tabs.Screen name="index" options={{title:'الرئيسية',tabBarIcon:({color,size})=><Ionicons name="grid-outline" color={color} size={size}/>}}/>
    <Tabs.Screen name="players" options={{title:'المواهب',tabBarIcon:({color,size})=><Ionicons name="people-outline" color={color} size={size}/>}}/>
    <Tabs.Screen name="live" options={{title:'AKN Live',tabBarIcon:({color,size})=><Ionicons name="pulse-outline" color={color} size={size}/>}}/>
    <Tabs.Screen name="opportunities" options={{title:'الفرص',tabBarIcon:({color,size})=><Ionicons name="trophy-outline" color={color} size={size}/>}}/>
    <Tabs.Screen name="profile" options={{title:'بطاقتي',tabBarIcon:({color,size})=><Ionicons name="person-circle-outline" color={color} size={size}/>}}/>
  </Tabs>;
}
