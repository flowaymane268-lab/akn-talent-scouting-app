import React from 'react';
import { ScrollView, View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Heading, Panel, Pill, C } from '../components/ui';
import { router } from 'expo-router';

function Metric({ value, label, icon }: { value: string; label: string; icon: keyof typeof Ionicons.glyphMap }) {
  return <View style={{ flex: 1, backgroundColor: C.panel2, borderRadius: 14, padding: 13, gap: 8 }}>
    <Ionicons name={icon} color={C.gold} size={20} />
    <Text style={{ color: C.text, fontSize: 21, fontWeight: '800', textAlign: 'right' }}>{value}</Text>
    <Text style={{ color: C.muted, fontSize: 11, textAlign: 'right' }}>{label}</Text>
  </View>;
}
export default function Home() {
  return <Screen>
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
        <View>
          <Text style={{ color: C.gold, fontSize: 11, fontWeight: '800', letterSpacing: 2 }}>AKN • TALENT SCOUTING</Text>
          <Text style={{ color: C.muted, fontSize: 11, marginTop: 4 }}>DISCOVER. DEVELOP. CONNECT.</Text>
        </View>
        <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: '#1B2940', borderWidth: 1, borderColor: C.gold, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: C.gold, fontWeight: '900', fontSize: 17 }}>AKN</Text>
        </View>
      </View>
      <Heading eyebrow="منصة اكتشاف المواهب" title="كل موهبة تستحق فرصة." subtitle="تطبيق تجريبي لبناء ملفات اللاعبين واكتشاف المواهب ومتابعة المباريات." />
      <Panel style={{ borderColor: '#806A3D', backgroundColor: '#171D29', marginBottom: 18 }}>
        <Pill>نسخة تجريبية • DEMO</Pill>
        <Text style={{ color: C.text, fontSize: 20, fontWeight: '800', textAlign: 'right', marginTop: 12 }}>ابدأ رحلة اكتشاف موهبتك</Text>
        <Text style={{ color: C.muted, textAlign: 'right', lineHeight: 21, marginTop: 7 }}>أنشئ ملفاً رياضياً منظماً، واعرض مهاراتك بطريقة واضحة وآمنة.</Text>
        <Pressable onPress={() => router.push('/profile')} style={{ backgroundColor: C.gold, padding: 13, borderRadius: 12, marginTop: 16, alignItems: 'center' }}>
          <Text style={{ color: '#101622', fontWeight: '800' }}>استكشف ملف اللاعب</Text>
        </Pressable>
      </Panel>
      <Text style={{ color: C.text, fontWeight: '800', fontSize: 16, textAlign: 'right', marginBottom: 12 }}>نظرة عامة</Text>
      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 22 }}>
        <Metric value="—" label="لاعبون موثقون" icon="people-outline" />
        <Metric value="—" label="كشافون معتمدون" icon="eye-outline" />
        <Metric value="—" label="فرص منشورة" icon="trophy-outline" />
      </View>
      <Panel>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Pill color={C.blue}>قريباً</Pill>
          <Text style={{ color: C.text, fontWeight: '800', fontSize: 16 }}>شبكة AKN</Text>
        </View>
        <Text style={{ color: C.muted, textAlign: 'right', lineHeight: 22, marginTop: 9 }}>النسخة الحالية تعمل محلياً على الهاتف. البحث السحابي، توثيق الحسابات، وربط الأندية تحتاج إلى خادم واختبارات قبل الإطلاق العام.</Text>
      </Panel>
      <Text style={{ color: C.muted, fontSize: 11, textAlign: 'center', marginTop: 20 }}>لا توجد بيانات لاعبين حقيقية في هذه النسخة التجريبية.</Text>
    </ScrollView>
  </Screen>;
}
