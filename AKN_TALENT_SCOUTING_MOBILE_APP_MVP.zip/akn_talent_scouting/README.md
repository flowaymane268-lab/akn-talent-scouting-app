# AKN TALENT SCOUTING — Mobile App MVP

This is an Expo / React Native mobile application project for Android and iOS. It is an app project, not a website.

## Included in this build
- Arabic-first mobile navigation and AKN identity.
- Player profile form with local on-device persistence (AsyncStorage).
- Search and filter over the local player profile and clearly labeled demo records.
- AKN Live manual match-event and score prototype.
- Opportunities screen with explicitly labeled examples.
- AI analysis roadmap and clear disclosure that automated video analysis is not connected yet.

## Important limitations
- This is an early MVP source project, not a finished global scouting network.
- No cloud database, authentication, real club/scout directory, live internet search, push notifications, upload pipeline, or AI model/API is connected.
- Demo players and opportunities are fictional examples and must not be presented as real.
- Match events are manually entered and stored only in screen state; they are not transmitted or persisted.
- Player profile is saved on the current device only. It is not submitted to AKN or visible to scouts.
- Do not enter sensitive identity/contact data. Guardian approval and a reviewed child-safety/privacy process are required before onboarding minors or publishing profiles.

## Build from a computer or cloud build service
1. Install Node.js LTS and dependencies with `npm install`.
2. Install EAS CLI: `npm install -g eas-cli`.
3. Sign in to an Expo account controlled by the project owner/guardian: `eas login`.
4. Configure the project: `eas build:configure`.
5. Android installable test build: `eas build --platform android --profile preview`.
6. iOS builds require Apple developer account eligibility, credentials, and Apple's review for App Store release.

## Phone-only workflow
The project source can be stored in GitHub and opened in a cloud development environment. A cloud build service can compile Android without a personal computer, but account setup, signing credentials, and store publishing may require an adult and may incur fees. Never share passwords or one-time codes in chat.

## Next engineering milestones
1. Add a secure backend, authentication, role permissions and database policies.
2. Add consent and moderation workflows before minors' profiles become discoverable.
3. Add verified organization/scout onboarding and evidence-backed opportunity listings.
4. Add secure video upload and AI analysis service; validate output with human reviewers.
5. Add audit logs, deletion/export tools, privacy policy, terms and incident handling.
6. Test on real Android/iOS devices, accessibility, performance and security before public release.
