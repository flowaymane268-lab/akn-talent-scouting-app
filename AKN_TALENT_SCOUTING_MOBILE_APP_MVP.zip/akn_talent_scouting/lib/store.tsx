import React, {createContext, useContext, useEffect, useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
export type Player = {name:string; country:string; age:string; position:string; club:string; foot:string; height:string; bio:string};
type Store = {player:Player; savePlayer:(p:Player)=>Promise<void>};
const empty:Player={name:'',country:'',age:'',position:'',club:'',foot:'',height:'',bio:''};
const Ctx=createContext<Store>({player:empty,savePlayer:async()=>{}});
export function StoreProvider({children}:{children:React.ReactNode}){const [player,setPlayer]=useState<Player>(empty); useEffect(()=>{AsyncStorage.getItem('akn.player.v1').then(v=>{if(v)setPlayer({...empty,...JSON.parse(v)})}).catch(()=>{});},[]); const savePlayer=async(p:Player)=>{setPlayer(p);await AsyncStorage.setItem('akn.player.v1',JSON.stringify(p));};return <Ctx.Provider value={{player,savePlayer}}>{children}</Ctx.Provider>}
export const useAKN=()=>useContext(Ctx);
