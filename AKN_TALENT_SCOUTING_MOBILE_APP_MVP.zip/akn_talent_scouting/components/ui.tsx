import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';

export const C = {
  bg: '#080D18', panel: '#111B2B', panel2: '#162237', line: '#26344A',
  gold: '#D6B56D', goldSoft: '#F0DCA9', text: '#F4F6FA', muted: '#9AA6B8',
  green: '#70C6A0', blue: '#75A9E8', red: '#E58B8B'
};

export function Screen({ children }: { children: React.ReactNode }) {
  return <View style={styles.screen}>{children}</View>;
}
export function Heading({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return <View style={{ marginBottom: 20 }}>
    {!!eyebrow && <Text style={styles.eyebrow}>{eyebrow.toUpperCase()}</Text>}
    <Text style={styles.heading}>{title}</Text>
    {!!subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
  </View>;
}
export function Panel({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.panel, style]}>{children}</View>;
}
export function Pill({ children, color = C.gold }: { children: React.ReactNode; color?: string }) {
  return <View style={[styles.pill, { borderColor: color + '66', backgroundColor: color + '18' }]}><Text style={{ color, fontSize: 11, fontWeight: '700' }}>{children}</Text></View>;
}
export const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg, paddingHorizontal: 20, paddingTop: 22 },
  eyebrow: { color: C.gold, fontSize: 10, fontWeight: '800', letterSpacing: 2, marginBottom: 7 },
  heading: { color: C.text, fontSize: 27, fontWeight: '800', textAlign: 'right' },
  subtitle: { color: C.muted, fontSize: 13, lineHeight: 21, textAlign: 'right', marginTop: 6 },
  panel: { backgroundColor: C.panel, borderColor: C.line, borderWidth: 1, borderRadius: 18, padding: 16 },
  pill: { borderWidth: 1, borderRadius: 30, paddingHorizontal: 10, paddingVertical: 5, alignSelf: 'flex-start' },
});
